import express from "express";
import {adminProfile} from '../controller/admin.controllers'
const router=express.Router()
router.post('/admin-profile',adminProfile)

export default router;