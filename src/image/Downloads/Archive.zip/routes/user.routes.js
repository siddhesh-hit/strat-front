import express from "express";
// console.log(userRoute)
import {myProfile,freindProfile} from '../controller/user.controllers'
// import {adminProfile} from '../controller/admin.controllers'

const router=express.Router()
router.post('/my-profile/:id',myProfile)
router.post('/friend-profile/:id',freindProfile)

// router.post('/getname',function(req,res){
//     console.log(req.body)
//   res.json({data:[req.body]})
// })
// router.post('/my-profile/:id',function(req,res){
//    res.json({
//        status:true,
//        data:req.params.id,
//        message:'my user profile'
//    })
// })

// router.post('/user/myprofile/:id',function(req,res){
//     res.json({
//         status:true,
//         data:req.params.id,
//         message:'my user profile'
//     })
//  })
export default router;