// npm install nodemon --save-dev
// require node ES6
// ES6 BAD KE COMMAND aapane app 
// var express =require('express');
// node version 14
//import top pe karna hai

import express from "express";

import userRoute from './routes/user.routes';
import adminRoute from './routes/admin.routes';
import mongoose from 'mongoose';
const app = express();
// app.use(userRoute)
	 app.use('/user',userRoute)
	 app.use('/admin',adminRoute)

	 mongoose.connect('mongodb://localhost:27017/mohinifirstdatabase')
	 .then(()=>{
		 console.log('mongodb connected')
	 }).catch(()=>{
		 console.log("Mongodb connection failed")
	 })
	 app.get('/', function (req, res) {
	  res.send('Hello World!');
	 });
	 app.get('/name', function (req, res) {
		res.send('Mohini!');
	   });
	   app.get('/name/:id', function (req, res) {
		res.send(req.params);
	   });
	   app.post
	 app.listen(9000, function () {
	  console.log('Example app listening on port 9000!');
	 });
// ==============================
// Lecture 7
// localhost:9000/User/login=>normal user