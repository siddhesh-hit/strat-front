export const myProfile=function (req,res){
    res.json({
        status:true,
        data:req.params.id,
        message:'my user profile'
    })
};
export const freindProfile=function (req,res){
    res.json({
        status:true,
        data:req.params.id,
        message:'my friend profile'
    })
};



// export const freindProfile=function (req,res){
//     res.json({
//         status:true,
//         data:req.params.id,
//         message:'my friend profile'
//     })
// };
