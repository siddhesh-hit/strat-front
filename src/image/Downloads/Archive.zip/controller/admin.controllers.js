export const adminProfile=function (req,res){
    res.json({
        status:true,
        data:req.body.id,
        message:'admin profile'
    })
};