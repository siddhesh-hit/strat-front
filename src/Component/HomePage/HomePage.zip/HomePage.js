import React, { useContext } from "react";
import { useEffect, useState } from "react";
import Wavinghand from "../../icons/wavinghand.svg";
import Whatsapp from "../../icons/Whatsapp1.svg";
import Youtude from "../../icons/Youtube1.svg";
import Clubhouse from "../../icons/Clubhouse1.svg";
import Craigslist from "../../icons/Craigslist1.svg";
import Facebook from "../../icons/Facebook1.svg";
import GitHub from "../../icons/Github1.svg";
import Gmail from "../../icons/Gmail1.svg";
import Google from "../../icons/Google1.svg";
import Instagram from "../../icons/Instagram1.svg";
import Linkedin from "../../icons/Linkedin1.svg";
import Line from "../../icons/Line1.svg";
import Medium from "../../icons/Monogram1.svg";
import Messenger from "../../icons/Messenger1.svg";
import Pinterest from "../../icons/Pinterest1.svg";
import ProductHunt from "../../icons/Producthunt1.svg";
import QQ from "../../icons/QQ1.svg";
import Quora from "../../icons/Quora1.svg";
import Reddit from "../../icons/Reddit1.svg";
import Salesnavigator from "../../icons/Sale1.svg";
import Slack from "../../icons/Slack1.svg";
import SMS from "../../icons/sms1.svg";
import Snapchat from "../../icons/Snap1.svg";
import Telegram from "../../icons/Telegram1.svg";
import Tiktok from "../../icons/Tiktok1.svg";
import Tumblr from "../../icons/Tumblr1.svg";
import Twitter from "../../icons/Twitter1.svg";
import Wechat from "../../icons/Wechat1.svg";
import YellowPages from "../../icons/YellowPage1.svg";
import SearchbarHome from "../SearchBarHome/SearchBar";
import NavHome from "../Navbar/NavHome";
import { AuthTokenContext } from "../../App";
import Topbar from "../Topbar";
import "../HomePage/HomePage.css";
import Banner from "./Banner";
import EmpowerTeam from "./EmpowerTeam";
import WhoItWork from "./WhoItWork";
import Footer from "./Footer";
import { useNavigate } from "react-router-dom";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
// import { Twitter } from "@mui/icons-material";
<link
  href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&family=Roboto:wght@100&display=swap"
  rel="stylesheet"
></link>;
function FrontPage({ setAuthToken }) {
  const authToken = useContext(AuthTokenContext);
  const navigate = useNavigate();
  const [all, al] = useState([]);
  const [some, sm] = useState([]);
  const [cpw, cp] = useState([]);
  const [seo, se] = useState([]);
  const [ecom, ec] = useState([]);
  const [oth, ot] = useState([]);
  
  useEffect(() => {
    const fetchData = async () => {
      let result = await fetch("http://localhost:5000/all_platforms", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await result.json();
      al(data);
    }

    const fetchData1 = async () => {
      let result = await fetch("https://strategystrapi.handsintechnology.in/sm_platforms", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await result.json();
      sm(data);
    }

    const fetchData2 = async () => {
      let result = await fetch("https://strategystrapi.handsintechnology.in/cp_platforms", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await result.json();
      cp(data);
    }

    const fetchData3 = async () => {
      let result = await fetch("https://strategystrapi.handsintechnology.in/seo_platforms", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await result.json();
      se(data);
    }

    const fetchData4 = async () => {
      let result = await fetch("https://strategystrapi.handsintechnology.in/ecom_platforms",{
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await result.json();
      ec(data);
    }
    const fetchData5 = async () => {
      let result = await fetch("https://strategystrapi.handsintechnology.in/oth_platforms",{
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await result.json();
      ot(data);
    }

    fetchData();
    fetchData1();
    fetchData2();
    fetchData3();
    fetchData4();
    fetchData5();
  }, [])
  return (
    <div className="Home_background">
      {/* {(authToken.length !== 0) ? <Topbar /> : <NavHome />} */}
      <NavHome setAuthToken={setAuthToken} />
      <h2 className="Landing-Page">
        <img src={Wavinghand} className="Wavinghand_space"></img>
        <b className="homepage_font padding-homepage">
          Hello, what are we creating today?
        </b>
      </h2>
      <p className="Landing-para homepage_font">
        Get started by selecting the idea type from the options below
      </p>
      <SearchbarHome />
      <div className="all_buttons container">
        {/* <button className="btn-all homepage_font active">All</button>
        <button className="socialmedia-btn homepage_font">Social Media</button>
        <button className="socialmedia-btn homepage_font">Copywriting</button>
        <button className="socialmedia-btn homepage_font">SEO</button>
        <button className="socialmedia-btn homepage_font">E-Commerce</button>
        <button className="socialmedia-btn homepage_font">Product</button> */}

        <Tabs
          id="controlled-tab-example"
          className="mb-3"
        >
          <Tab className="tabsss" eventKey="all" title="All">
            <div className="all-channels container">
              <div className="row">
                {all.map(data => (
                  <div className="col-lg-4">
                    <div className="display11">
                      <div className="icon"> <img src={"https://strategytooladmin.handsintechnology.in" + data.url} className="iconns"></img>
                      </div>
                      <div className="padd">
                        <h6 className="channel_content_h6 homepage_font">{data.text}</h6>
                        <p className=" homepage_font"> {data.description} </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Tab>
          <Tab className="tabsss" eventKey="social media" title="Social Media">
            <div className="all-channels container">
              <div className="row">
                {some.map(data => (
                  <div className="col-lg-4">
                    <div className="display11">
                      <div className="icon"> <img src={"https://strategytooladmin.handsintechnology.in" + data.url} className="iconns"></img>
                      </div>
                      <div className="padd">
                        <h6 className="channel_content_h6 homepage_font">{data.text}</h6>
                        <p className=" homepage_font"> {data.description} </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Tab>
          <Tab className="tabsss" eventKey="copywriting" title="Copywriting">
            <div className="all-channels container">
              <div className="row">
                {cpw.map(data => (
                  <div className="col-lg-4">
                    <div className="display11">
                      <div className="icon"> <img src={"https://strategytooladmin.handsintechnology.in" + data.url} className="iconns"></img>
                      </div>
                      <div className="padd">
                        <h6 className="channel_content_h6 homepage_font">{data.text}</h6>
                        <p className=" homepage_font"> {data.description} </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Tab>
          <Tab className="tabsss" eventKey="seo" title="SEO">
            <div className="all-channels container">
              <div className="row">
                {seo.map(data => (
                  <div className="col-lg-4">
                    <div className="display11">
                      <div className="icon"> <img src={"https://strategytooladmin.handsintechnology.in" + data.url} className="iconns"></img>
                      </div>
                      <div className="padd">
                        <h6 className="channel_content_h6 homepage_font">{data.text}</h6>
                        <p className=" homepage_font"> {data.description} </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Tab>
          <Tab className="tabsss" eventKey="e-commerce" title="E-Commerce">
            <div className="all-channels container">
              <div className="row">
                {ecom.map(data => (
                  <div className="col-lg-4">
                    <div className="display11">
                      <div className="icon"> <img src={"https://strategytooladmin.handsintechnology.in" + data.url} className="iconns"></img>
                      </div>
                      <div className="padd">
                        <h6 className="channel_content_h6 homepage_font">{data.text}</h6>
                        <p className=" homepage_font"> {data.description} </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Tab>
          <Tab className="tabsss" eventKey="other" title="Others">
            <div className="all-channels container">
              <div className="row">
                {oth.map(data => (
                  <div className="col-lg-4">
                    <div className="display11">
                      <div className="icon"> <img src={"https://strategytooladmin.handsintechnology.in" + data.url} className="iconns"></img>
                      </div>
                      <div className="padd">
                        <h6 className="channel_content_h6 homepage_font">{data.text}</h6>
                        <p className=" homepage_font"> {data.description} </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Tab>
        </Tabs>
      </div>
      <Banner />
      <EmpowerTeam />
      <WhoItWork />
      <Footer />
    </div>
  );
}
export default FrontPage;
